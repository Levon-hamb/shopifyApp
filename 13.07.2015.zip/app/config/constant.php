<?php
define('SITE_URL', 'http://inspiratee.dev');

?>