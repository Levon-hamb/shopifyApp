@extends('layouts.template')

@section('content')

<div class="container">
    <div class="row">
        <a href="/productTemplates" class="btn btn-default">Product Templates</a>
        <a href="/createProduct" class="btn btn-default">Create Product</a>
    </div>



</div>


@stop