
    <script src="{{ asset('/resources/js/jquery-2.1.4.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('/resources/js/main.js') }}" type="text/javascript"></script>
    <script src="{{ asset('/resources/ckeditor/ckeditor.js')}}"  type="text/javascript" ></script>
    <script src="{{ asset('/resources/ckeditor/adapters/jquery.js')}}"  type="text/javascript" ></script>
</body>

</html>