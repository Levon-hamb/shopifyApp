<html>
<head>
    <link href="{{ asset('/resources/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('/resources/bootstrap/css/styles.css') }}" rel="stylesheet">
    <link href="{{ asset('/resources/css/custom.css') }}" rel="stylesheet">
</head>
<body>



